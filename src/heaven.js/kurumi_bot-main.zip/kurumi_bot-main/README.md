<h1 align="center"> Kurumi Tokisaki Bot

</div>
<p align="center">
  
  <img src="https://telegra.ph/file/08b8f4f754693568ce929.jpg" width="360" border="0" alt="PFP">
</h3>

<p align="center">
Kurumi Tokisaki
  
<h3 align="center"> The Future Is Here

## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=FF0000&lines=ɪ'ᴍ+kurumi-Tokisaki+ᴀ+WhatsApp+ʙᴏᴛ;ᴍᴀᴅᴇ+ʙʏ+Deryl+and+Aku-the-overthinker.)](https://git.io/typing-svg)
<br>

<h2> 🎐 Deloying Buttons 🎐
</h2> 
Click here<details Close>

<summary></summary>

<h4 align="center" >
    <a href="https://heroku.com/deploy?template=https://github.com/Push-b/kurumi-bot">
    <img src="https://www.herokucdn.com/deploy/button.svg" width="150px" alt="Deploy on Heroku" >
    </a>

<h4 align="center"> 
<a href="https://app.koyeb.com/apps/deploy?type=docker&image=quay.io/Push-b/kurumi-bot:main&env[PORT]=3000&env[PREFIX]=-&&env[MONGODB]=mongodb://mongo:a2H5ECgq2f3z1eW8DwGY@containers-us-west-24.railway.app:5516&&env[SESSION]=enterYourSession&&env[MODS]=918961331275&&env[Chat_Bot_Url]=http://api.brainshop.ai/get?bid=[bid]&key=[key]&uid=[uid]&msg=[msg]">
    <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy on Koyeb" width="140px">
    </a>

<h4 align="center"> 
<a href="https://railway.app">
<img src="https://railway.app/button.svg" alt="Deploy on Railway" width="150px">
</a>
 
<h4 align="center"> 
<a href="https://repl.it/github/Aurora-Private">
<img src= "https://img.shields.io/badge/replit-253c99?style=for-the-badge&logo=replit&logoColor=F26207"alt="Deploy on Replit" width="150px">
</a>
</p>
</h4>

</div>

</details>

<a><img src="https://i.ibb.co/7Kk6XSg/Rainbow.gif" width="100%">

<br>
      
ENV | VALUES
-- | --
NAME | The name of your bot (Kurumi Tokisaki) 
PREFIX | The prefix of your bot can be a symbol (/)
MODS | Phone numbers in this format (`263788671***`) without `+` or `SPACE` and for more numbers put a "," between them.
PORT | The port on which your bot will run (3000)
MONGODB | Your MongoDB URL ()
SESSION | Any random value and try to keep it copied
SESSION_URL | Your Mongo URL will be used here ()

<br>

---

<h2 align="center">🔰 Meet Kurumi Devs 🔰
</h2>

| [![Deryl](https://github.com/Push-b.png)](https://github.com/Push-b) Stress_Giver | [![Aku the ovethinker](https://github.com/Eximinati.png)](https://github.com/Eximinati) Aku the thinker |
|--- | --- |
| [Deryl](https://github.com/Push-b) Owner, developer, monthly maintainer,  function developer |  [Aku](https://github.com/Eximinati) co-Owner, developer, baileys and dependencies maintainer,  function developer |
|--- | --- | 
| [![Deryl](https://github.com/JFLEX019.png)](https://github.com/JFLEX019) JFLEX the coder aassist|
